from .dal_access import BaseDal, CRUDDal
