from .decorators import fake_request_test
from .test_case import BaseTestCase
