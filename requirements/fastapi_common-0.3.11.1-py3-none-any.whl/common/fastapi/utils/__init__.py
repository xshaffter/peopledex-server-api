from .functions import is_manager_param, is_bool_param, is_list_param, is_str_param, first_or_none
from .singleton import Singleton
